# AI chatbot (hosted)

I have hosted [this](https://github.com/VishankSingh/chatbot-tensorflow_v2.3.0) AI chatbot using a website using Flask. If you ask why Flask, simply because it is easy :) <br>
PS- the design looks trash

